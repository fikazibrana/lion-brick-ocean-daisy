//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Ci22B4wv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/cara-kerja",
			"/kontak",
			"/layanan",
			"/rate-card"
		],
		preloads: ["/assets/index-BTofHVmo.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BTofHVmo.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Vs0V2-It.js",
			"/assets/chrome-DIdTeoGW.js",
			"/assets/rate-cards-Ckv1whEu.js"
		]
	},
	"/cara-kerja": {
		filePath: "/workspace/src/routes/cara-kerja.tsx",
		children: void 0,
		preloads: ["/assets/cara-kerja-DJvV7d4W.js", "/assets/chrome-DIdTeoGW.js"]
	},
	"/kontak": {
		filePath: "/workspace/src/routes/kontak.tsx",
		children: void 0,
		preloads: ["/assets/kontak-BsDAkTWb.js", "/assets/chrome-DIdTeoGW.js"]
	},
	"/layanan": {
		filePath: "/workspace/src/routes/layanan.tsx",
		children: void 0,
		preloads: ["/assets/layanan-Cjo9ujaY.js", "/assets/chrome-DIdTeoGW.js"]
	},
	"/rate-card": {
		filePath: "/workspace/src/routes/rate-card.tsx",
		children: void 0,
		preloads: [
			"/assets/rate-card-c-MXy9_9.js",
			"/assets/chrome-DIdTeoGW.js",
			"/assets/rate-cards-Ckv1whEu.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
