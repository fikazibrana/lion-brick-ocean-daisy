import { _ as steps, a as formatRupiah, d as packages, h as services, n as audiences, p as reasons, t as angles, u as notPromised } from "./site-Ctc9uy_K.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as btnPrimary, i as btnGhost, n as Shell, r as Stamp } from "./chrome-jF7PpaCG.mjs";
import { t as RateCards } from "./rate-cards-CgG71Quy.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-SSDbDnaR.js
var import_jsx_runtime = require_jsx_runtime();
function HomePage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-end gap-10 px-5 py-12 sm:px-8 sm:py-16 lg:grid-cols-12 lg:gap-12 lg:py-20",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-stamp uppercase",
							children: "Artikel · press release · naskah konten"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "display mt-4 text-4xl text-ink sm:text-5xl lg:text-6xl",
							children: [
								"Tulisan yang tembus.",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-stamp",
									children: "Cepat viral."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-lg leading-relaxed text-ink-soft",
							children: "Tembus Media menulis artikel, press release, dan naskah konten untuk politikus, juru bicara, dan institusi. Nama media tidak dipajang di situs ini."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-col gap-3 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/kontak",
								search: { paket: "B" },
								className: btnPrimary,
								children: "Kirim brief"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/rate-card",
								className: btnGhost,
								children: "Lihat rate card"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "bg-sheet p-6 shadow-print sm:p-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-3 border-b border-ink pb-3 text-xs font-semibold tracking-widest uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Contoh susunan" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-stamp",
									children: "Bukan tayangan nyata"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 text-xs font-semibold tracking-widest text-muted uppercase",
								children: "Kanal politik"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-2 font-serif text-3xl leading-tight text-ink",
								children: "Pernyataan resmi, dengan kutipan yang boleh dipakai redaksi"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 leading-relaxed text-ink-soft",
								children: "Naskah memakai 5W+1H dan satu suara narasumber. Bukan judul jebakan. Delapan media lokal mengikuti wilayah di brief."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
								className: "mt-6 grid grid-cols-3 gap-3 border-t border-line pt-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs font-semibold tracking-widest text-muted uppercase",
										children: "Nasional"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-serif text-2xl",
										children: "1–3"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs font-semibold tracking-widest text-muted uppercase",
										children: "Lokal"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-serif text-2xl",
										children: "8"
									})] }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
										className: "text-xs font-semibold tracking-widest text-muted uppercase",
										children: "Laporan"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
										className: "mt-1 font-serif text-2xl",
										children: "Tautan"
									})] })
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-6 flex justify-end",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stamp, {})
							})
						]
					})
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-b border-ink",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mx-auto grid max-w-6xl divide-y divide-line sm:grid-cols-3 sm:divide-x sm:divide-y-0",
				children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/rate-card",
					className: "block px-5 py-5 sm:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-xs font-semibold tracking-widest text-muted uppercase",
						children: [
							"Paket ",
							item.id,
							" · ",
							item.national,
							" nasional + ",
							item.local,
							" lokal"
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mt-1 block font-serif text-3xl text-ink tabular-nums",
						children: formatRupiah(item.price)
					})]
				}) }, item.id))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "border-b border-line",
			"aria-labelledby": "alasan",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 pt-14 sm:px-8 sm:pt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold tracking-widest text-stamp uppercase",
					children: "01 — Kenapa ini"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "alasan",
					className: "mt-2 max-w-2xl font-serif text-3xl text-ink sm:text-4xl",
					children: "Bukan ledakan portal. Dua lapis yang bisa dijelaskan ke atasan."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mx-auto mt-8 max-w-6xl divide-y divide-line border-t border-line md:grid md:grid-cols-3 md:divide-x md:divide-y-0",
				children: reasons.map((reason, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "px-5 py-8 sm:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-serif text-4xl text-stamp",
							children: ["0", index + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-3 font-serif text-2xl text-ink",
							children: reason.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 leading-relaxed text-ink-soft",
							children: reason.body
						})
					]
				}, reason.title))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line",
			"aria-labelledby": "siapa",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:px-8 sm:py-16 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-stamp uppercase",
							children: "02 — Untuk siapa"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							id: "siapa",
							className: "mt-2 font-serif text-3xl text-ink sm:text-4xl",
							children: "Cocok bila pernyataan Anda punya publik."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 leading-relaxed text-ink-soft",
							children: "Bukan untuk promosi produk, diskon, atau pemburu backlink. Kalau yang dibutuhkan adalah katalog, ini meja yang salah."
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "lg:col-span-8",
					children: audiences.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-t border-line py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-serif text-xl text-ink",
							children: item.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-ink-soft",
							children: item.body
						})]
					}, item.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line",
			"aria-labelledby": "paket",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-stamp uppercase",
						children: "03 — Rate card"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "paket",
						className: "mt-2 font-serif text-3xl text-ink sm:text-4xl",
						children: "Tiga paket. Angkanya tidak bergeser."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/rate-card",
						className: "font-semibold text-stamp",
						children: "Rincian yang termasuk"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RateCards, {})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line",
			"aria-labelledby": "tayang",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-stamp uppercase",
						children: "04 — Layanan"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "tayang",
						className: "mt-2 max-w-2xl font-serif text-3xl text-ink sm:text-4xl",
						children: "Tiga pekerjaan. Tidak lebih."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 md:grid-cols-3",
						children: services.map((service) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "border border-line bg-sheet p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "font-serif text-2xl text-ink",
									children: service.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 leading-relaxed text-ink-soft",
									children: service.body
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/kontak",
									search: { paket: service.id },
									className: "mt-4 inline-flex min-h-11 items-center font-semibold text-stamp",
									children: ["Ajukan ", service.title.toLowerCase()]
								})
							]
						}, service.id))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line",
			"aria-labelledby": "sudut",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-stamp uppercase",
						children: "Contoh sudut"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "sudut",
						className: "mt-2 font-serif text-3xl text-ink sm:text-4xl",
						children: "Yang biasa dikerjakan. Bukan portofolio palsu."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-4 md:grid-cols-3",
						children: angles.map((angle) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "border-t-2 border-stamp pt-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-semibold tracking-widest text-muted uppercase",
									children: angle.kicker
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-2 font-serif text-2xl text-ink",
									children: angle.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 leading-relaxed text-ink-soft",
									children: angle.body
								})
							]
						}, angle.title))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-line",
			"aria-labelledby": "alur",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-between gap-4 sm:flex-row sm:items-end",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-stamp uppercase",
						children: "05 — Alur"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "alur",
						className: "mt-2 font-serif text-3xl text-ink sm:text-4xl",
						children: "Lima langkah. Distribusi baru setelah setuju."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/cara-kerja",
						className: "font-semibold text-stamp",
						children: "Ketentuan lengkap"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-5",
					children: steps.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-serif text-3xl text-stamp",
							children: ["0", index + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 font-serif text-xl text-ink",
							children: step.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm leading-relaxed text-ink-soft",
							children: step.body
						})
					] }, step.title))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			"aria-labelledby": "tidak",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "tidak",
					className: "font-serif text-3xl text-ink sm:text-4xl",
					children: "Yang tidak kami janjikan"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-6 border-t border-line",
					children: notPromised.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid gap-2 border-b border-line py-4 sm:grid-cols-[5rem_1fr] sm:gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-semibold tracking-widest text-stamp uppercase",
							children: "Tidak"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "leading-relaxed text-ink-soft",
							children: item
						})]
					}, item))
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-night text-night-fg",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-end gap-8 px-5 py-14 sm:px-8 sm:py-16 lg:grid-cols-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-7",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold tracking-widest text-stamp uppercase",
						children: "Brief"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "display mt-3 text-4xl sm:text-5xl",
						children: "Kirim sudut beritanya. Naskah tidak berangkat sebelum Anda setuju."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "leading-relaxed text-night-muted",
						children: "Chat WhatsApp 0857 8636 1591. Sebut layanan, bahan, dan tenggat. Instagram @tembusmedia."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/kontak",
						search: { paket: "B" },
						className: btnPrimary + " mt-6",
						children: "Susun brief"
					})]
				})]
			})
		})
	] });
}
var SplitComponent = function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {}) });
};
//#endregion
export { SplitComponent as component };
