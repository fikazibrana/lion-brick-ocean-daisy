import { g as site, h as services } from "./site-Ctc9uy_K.mjs";
import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as Shell, t as PageIntro } from "./chrome-jF7PpaCG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/layanan-CudhgrRY.js
var import_jsx_runtime = require_jsx_runtime();
function ServicesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageIntro, {
		kicker: "Layanan",
		title: "Artikel, press release, dan naskah konten.",
		dek: "Hanya tiga ini. Nama media tidak dipublikasikan. Penempatan press release dibahas lewat WhatsApp, bukan dipajang sebagai daftar."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
			className: "border-t border-ink",
			children: services.map((service, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "grid gap-3 border-b border-line py-6 sm:grid-cols-[6rem_16rem_1fr] sm:items-start sm:gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-serif text-3xl text-stamp",
						children: ["0", index + 1]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-serif text-2xl text-ink",
						children: service.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "leading-relaxed text-ink-soft",
						children: service.body
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/kontak",
						search: { paket: service.id },
						className: "mt-3 inline-flex min-h-11 items-center font-semibold text-stamp",
						children: "Ajukan lewat WhatsApp"
					})] })
				]
			}, service.id))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-8 max-w-2xl text-sm leading-relaxed text-muted",
			children: [
				"Press release memakai rate card Paket A–C. Artikel dan naskah konten menyesuaikan panjang serta tenggat. Hubungi ",
				site.phoneDisplay,
				" atau ",
				site.instagram,
				"."
			]
		})]
	})] });
}
//#endregion
export { ServicesPage as component };
