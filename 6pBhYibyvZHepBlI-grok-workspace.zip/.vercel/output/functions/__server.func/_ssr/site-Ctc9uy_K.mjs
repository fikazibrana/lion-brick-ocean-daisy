//#region node_modules/.nitro/vite/services/ssr/assets/site-Ctc9uy_K.js
var site = {
	name: "Tembus Media",
	domain: "tembusmedia.online",
	tagline: "#cepatviral",
	phoneDisplay: "0857 8636 1591",
	phoneTel: "+6285786361591",
	whatsappE164: "6285786361591",
	instagram: "@tembusmedia",
	instagramUrl: "https://www.instagram.com/tembusmedia/"
};
var nav = [
	{
		to: "/",
		label: "Beranda"
	},
	{
		to: "/layanan",
		label: "Layanan"
	},
	{
		to: "/rate-card",
		label: "Rate card"
	},
	{
		to: "/cara-kerja",
		label: "Cara kerja"
	},
	{
		to: "/kontak",
		label: "Kontak"
	}
];
var packages = [
	{
		id: "A",
		name: "Fokus Daerah",
		price: 2e6,
		national: 1,
		local: 8,
		blurb: "Kegiatan, kunjungan kerja, dan pernyataan rutin.",
		featured: false
	},
	{
		id: "B",
		name: "Dua Pintu",
		price: 3e6,
		national: 2,
		local: 8,
		blurb: "Isu yang perlu dua pintu pembaca nasional.",
		featured: true
	},
	{
		id: "C",
		name: "Momen Penting",
		price: 4e6,
		national: 3,
		local: 8,
		blurb: "Klarifikasi, program unggulan, dan momen yang tidak boleh salah sudut.",
		featured: false
	}
];
var included = [
	"Satu naskah press release",
	"Dua kali revisi",
	"Distribusi sesuai jumlah paket",
	"Tayang mengikuti kebijakan media",
	"Laporan tautan dan tangkapan layar",
	"Konsultasi sudut berita, singkat"
];
var excluded = [
	"Wawancara eksklusif",
	"Jaminan judul utama atau top stories",
	"Janji jumlah pembaca",
	"Daftar nama media yang dipajang di situs"
];
var services = [
	{
		id: "artikel",
		title: "Penulisan artikel",
		body: "Artikel yang siap dibaca: sudut yang jelas, fakta yang dicek, dan bahasa yang tidak bertele-tele."
	},
	{
		id: "B",
		title: "Jasa press release",
		body: "Naskah rilis dan distribusi sesuai paket. Nama media tidak dipajang di situs. Penempatannya dibahas saat brief."
	},
	{
		id: "naskah",
		title: "Pembuatan naskah konten",
		body: "Naskah untuk unggahan, siaran, dan materi publik yang ingin cepat sampai, tanpa mengorbankan fakta."
	}
];
var audiences = [
	{
		title: "Politikus dan kepala daerah",
		body: "Pernyataan, kunjungan kerja, dan program yang harus sampai ke luar grup internal."
	},
	{
		title: "Tim media partai dan fraksi",
		body: "Satu narasi yang rapi, dengan pintu nasional dan pintu daerah dalam brief yang sama."
	},
	{
		title: "Juru bicara lembaga dan pemda",
		body: "Rilis yang bisa dipertanggungjawabkan: fakta, kutipan, dan kalimat yang sudah disetujui."
	},
	{
		title: "Ormas dan tokoh publik",
		body: "Masuk percakapan nasional tanpa kehilangan gema di wilayah akar rumput."
	},
	{
		title: "Asosiasi dan urusan publik perusahaan",
		body: "Saat isu menyentuh kebijakan, bukan saat yang dijual adalah produk."
	},
	{
		title: "Akademisi",
		body: "Pandangan yang disusun agar bisa dikutip, lengkap dengan konteks."
	}
];
var reasons = [
	{
		title: "Dua lapis dalam satu rilis",
		body: "Media nasional memberi legitimasi. Delapan media lokal membawa pernyataan yang sama ke wilayah yang Anda tunjuk."
	},
	{
		title: "Daerahnya tidak diundi",
		body: "Delapan media lokal mengikuti provinsi, dapil, atau campuran wilayah. Bukan daftar yang sama untuk setiap klien."
	},
	{
		title: "Naskah, bukan tembakan massal",
		body: "Sudut berita, kutipan resmi, dan 5W+1H. Laporan tautan disimpan untuk arsip tim media dan atasan."
	}
];
var angles = [
	{
		kicker: "Kegiatan",
		title: "Kunjungan kerja di dapil",
		body: "Satu kutipan, fakta lapangan, dan delapan media lokal di wilayah yang didatangi."
	},
	{
		kicker: "Program",
		title: "Program yang perlu dikenal",
		body: "Siapa penerimanya, di mana berjalannya, dan dua atau tiga pintu nasional supaya tidak berhenti di siaran internal."
	},
	{
		kicker: "Klarifikasi",
		title: "Pernyataan yang waktunya sempit",
		body: "Naskah dikunci dulu. Tidak ada kalimat yang berangkat di luar brief yang Anda setujui."
	}
];
var steps = [
	{
		title: "Brief",
		body: "Siapa yang bicara, sudut berita, kutipan, foto bila ada, wilayah delapan media lokal, dan tenggat."
	},
	{
		title: "Naskah",
		body: "Satu press release. Dua kali revisi. Target penulisan: satu hari kerja setelah bahan lengkap."
	},
	{
		title: "Persetujuan",
		body: "Tidak ada distribusi sebelum Anda menyetujui naskah."
	},
	{
		title: "Tayang",
		body: "Target 1–3 hari kerja setelah naskah disetujui, mengikuti antrean media."
	},
	{
		title: "Laporan",
		body: "Tautan dan tangkapan layar, paling lambat satu kali 24 jam setelah tayang."
	}
];
var refusals = [
	"Hoaks, fitnah, ujaran kebencian, dan materi yang menghasut.",
	"Kampanye hitam, serangan personal, dan konten yang berisiko melanggar ketentuan pemilu atau UU ITE.",
	"Klaim tanpa sumber yang bersedia dikutip.",
	"Permintaan agar rilis terkesan seperti liputan investigasi yang independen."
];
var notPromised = [
	"Daftar nama media di halaman situs. Penempatan dibicarakan di brief, tidak dipajang.",
	"Liputan yang seolah ditulis wartawan secara independen. Ini jasa penulisan dan distribusi. Jika media menandai materi berbayar, penandaan itu mengikuti kebijakan mereka.",
	"Judul utama, posisi trending, atau jumlah pembaca tertentu."
];
var materials = [
	"Nama, jabatan, dan lembaga narasumber",
	"Kutipan yang boleh dipakai, atau poin yang wajib masuk",
	"Fakta: tanggal, tempat, angka, dan nama program",
	"Foto yang hak pakainya jelas, bila ada",
	"Wilayah untuk delapan media lokal",
	"Kalimat atau nama yang tidak boleh ditulis"
];
var faqs = [
	{
		q: "Kenapa nama media tidak ditulis di situs?",
		a: "Daftar media tidak dipublikasikan. Jumlahnya mengikuti paket, sedangkan nama penempatannya dibahas langsung lewat WhatsApp saat brief."
	},
	{
		q: "Bolehkah delapan media lokal dipilih menurut dapil?",
		a: "Boleh. Sebut provinsi, kabupaten, atau cakupan daerah pemilihan di brief. Itu yang dipakai menyusun daftar, bukan delapan portal acak."
	},
	{
		q: "Berapa lama sampai tayang?",
		a: "Naskah ditargetkan satu hari kerja setelah bahan lengkap. Tayang ditargetkan 1–3 hari kerja setelah Anda setuju. Laporan tautan menyusul paling lambat satu kali 24 jam setelah tayang."
	},
	{
		q: "Apakah ini sama dengan liputan wartawan?",
		a: "Tidak. Tembus Media menulis dan mendistribusikan press release. Redaksi media tetap punya kebijakan sendiri, termasuk penandaan jika materi itu berbayar."
	},
	{
		q: "Materi apa yang ditolak?",
		a: "Hoaks, fitnah, SARA, kampanye hitam, dan bahan yang tidak dapat dipertanggungjawabkan. Jika ragu, kirim dulu pokoknya. Kami katakan terus terang bila tidak bisa dikerjakan."
	}
];
function formatRupiah(value) {
	return new Intl.NumberFormat("id-ID", {
		style: "currency",
		currency: "IDR",
		maximumFractionDigits: 0
	}).format(value);
}
function isPaketId(value) {
	return value === "A" || value === "B" || value === "C" || value === "artikel" || value === "naskah";
}
function paketLabel(id) {
	if (id === "artikel") return "Penulisan artikel";
	if (id === "naskah") return "Pembuatan naskah konten";
	const item = packages.find((entry) => entry.id === id);
	return item ? `Press release Paket ${item.id} — ${item.name}` : id;
}
//#endregion
export { steps as _, formatRupiah as a, materials as c, packages as d, paketLabel as f, site as g, services as h, faqs as i, nav as l, refusals as m, audiences as n, included as o, reasons as p, excluded as r, isPaketId as s, angles as t, notPromised as u };
