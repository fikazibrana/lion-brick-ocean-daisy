import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/chrome";
import { HomePage } from "@/components/home";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [{ title: "Tembus Media — Artikel, press release, naskah konten" }],
  }),
  component: function Home() {
    return (
      <Shell>
        <HomePage />
      </Shell>
    );
  },
});
