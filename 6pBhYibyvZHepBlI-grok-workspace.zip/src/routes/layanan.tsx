import { createFileRoute, Link } from "@tanstack/react-router";
import { PageIntro, Shell } from "@/components/chrome";
import { services, site } from "@/lib/site";

export const Route = createFileRoute("/layanan")({
  head: () => ({
    meta: [{ title: "Layanan — Tembus Media" }],
  }),
  component: ServicesPage,
});

function ServicesPage() {
  return (
    <Shell>
      <PageIntro
        kicker="Layanan"
        title="Artikel, press release, dan naskah konten."
        dek="Hanya tiga ini. Nama media tidak dipublikasikan. Penempatan press release dibahas lewat WhatsApp, bukan dipajang sebagai daftar."
      />
      <section className="mx-auto max-w-6xl px-5 py-14 sm:px-8 sm:py-16">
        <ol className="border-t border-ink">
          {services.map((service, index) => (
            <li
              key={service.id}
              className="grid gap-3 border-b border-line py-6 sm:grid-cols-[6rem_16rem_1fr] sm:items-start sm:gap-6"
            >
              <span className="font-serif text-3xl text-stamp">0{index + 1}</span>
              <h2 className="font-serif text-2xl text-ink">{service.title}</h2>
              <div>
                <p className="leading-relaxed text-ink-soft">{service.body}</p>
                <Link
                  to="/kontak"
                  search={{ paket: service.id }}
                  className="mt-3 inline-flex min-h-11 items-center font-semibold text-stamp"
                >
                  Ajukan lewat WhatsApp
                </Link>
              </div>
            </li>
          ))}
        </ol>
        <p className="mt-8 max-w-2xl text-sm leading-relaxed text-muted">
          Press release memakai rate card Paket A–C. Artikel dan naskah konten menyesuaikan panjang
          serta tenggat. Hubungi {site.phoneDisplay} atau {site.instagram}.
        </p>
      </section>
    </Shell>
  );
}
